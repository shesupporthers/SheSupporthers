from django.apps import AppConfig


class JobappConfig(AppConfig):
    name = 'jobapp'
