from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
    path("",views.sheHome,name='sheHome'),
    path("shehome",views.sheHome,name='sheHome'),
    path("health",views.health,name='health'),
    path("education",views.education,name='education'),
    path("login1",views.login1,name='login1'),
    path("register",views.register,name='register'),
    path("contact",views.contact,name='contact'),
    path("about",views.about,name='about'),
    path("job",views.job,name='job')
    
]