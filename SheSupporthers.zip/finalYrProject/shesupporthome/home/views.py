from datetime import date, datetime
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login
from home.models import Contact
# Create your views here.

def sheHome(request):
    return render(request,'sheHome.html')

def health(request):
    return render(request,'healthcare.html')

def education(request):
    return render(request,'education.html') 

def about(request):
    return render(request,'about.html')     

def contact(request):
    if request.method=='POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        comment = request.POST['comment']
        print(name,email,phone,comment)
        contact = Contact(name=name, email=email, phone=phone, comment=comment)
        contact.save()
    return render(request,'contact.html') 

def job(request):
    return render(request,'job')

def register(request):
    if request.method == "POST":
         username = request.POST['username']
         email = request.POST['email']
         password = request.POST['password']

         myuser = User.objects.create_user(username,email,password)

         myuser.save()

         messages.success(request,"Your have successfully registered!")
         return redirect('login1')
    return render(request,'register.html')

def login1(request):
    if request.method == 'POST':
        name = request.POST['name']
        password = request.POST['password']
        
        user = authenticate(username=name, password=password) # authenticate function kisney lika 
        

        if user is not None:
            login(request,user)
            name = user.username
            messages.success(request,"logged in successfully")

            return render(request,'sheHome.html',{'name':name})  #code edar break ho raha hai
        else:
            messages.error(request,"not logged in")
            return redirect('sheHome')     
    return render(request,'login1.html')
    